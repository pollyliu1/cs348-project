import from student.txt of del insert into student;
import from faculty.txt of del insert into faculty;
import from class.txt of del insert into class;
import from enrolled.txt of del insert into enrolled;
