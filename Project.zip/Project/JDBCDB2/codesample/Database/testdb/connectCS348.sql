connect to CS348;
